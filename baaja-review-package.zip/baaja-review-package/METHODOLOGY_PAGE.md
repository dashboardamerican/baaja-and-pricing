# Methodology and full source links

## Project load and calculate upgrade costs

We interpolate between LBNL's 192 TWh in 2024 and 464 TWh in 2028 to get 298.476 TWh in 2026, then reach 649 TWh in 2030. Growth after 2030 is our assumption. New covered MW = (annual TWh - 298.476) x 1,000,000 / (8,760 x 0.80) x 0.75. Each year's added MW costs $650,000/MW, rising 1% annually from 2026. [2, 3] The faster case uses 649 x EIA server-use[y]/server-use[2030], then extends the 2049-2050 growth rate through 2056. [6]

Annual capital recovery = capital x 0.05 / (1 - 1.05^(-40)). Add 1.5% of capital for operations and maintenance. In the baseline, data centers already pay 35% of capital recovery directly, but no operating costs directly. Existing load and network cost K grow 1% a year. Half of covered growth is assigned to PJM billing areas; the rest goes to the remaining U.S. system. These are model assumptions. [3, 4, 7-15]

## Calculate who pays

For each region/year: K = annual existing-network cost; C = annual assigned-upgrade cost; D = annual equivalent of existing direct upgrade funding; s = new data centers' share of billing demand. The baseline collects D directly and shares the remaining costs. AND collects C directly and removes it from shared rates, leaving K. [1, 3]

Baseline = D + s(K + C - D). AND = C + sK. Extra payments = (1-s)(C-D).

Above higher-of = AND - max(baseline, C). Add results across regions and years 2030-2056.

## Check the totals and compare with the ITC

In $bn: AND 232.975 - baseline 176.955 = 56.020 extra. AND - higher-of 177.396 = 55.579 above that benchmark. JCT's annual costs for 2022-2031 are 0, 0, 0, .788, 1.213, 1.213, 1.213, 2.001, 2.426, 2.425. Our 30-year ITC comparison = 3 x sum(cost[y] / 1.025^(y-2026)) = $31.674bn; 56.020 / 31.674 = 1.77. The extension is our calculation, not a JCT score; the ratio compares dollar amounts, not equivalent benefits. [3, 5]

## Sources

[1] S.5653 IS: section 2107(a)(3)-(4), pp.229-231; separate FPA 228(f), p.240.  
https://www.govinfo.gov/content/pkg/BILLS-119s5653is/pdf/BILLS-119s5653is.pdf

[2] LBNL 2025 Update (June 2026): printed pp.8-9, physical PDF pp.10-11.  
https://www.energy.gov/documents/united-states-data-center-energy-usage-report-2025-update

[3] Review guide: input files, source cells, equations and calculation checks.  
https://github.com/dashboardamerican/baaja-and-pricing/blob/main/analysis/fresh-central-2026-10-31/REVIEW_GUIDE.md

[4] AEP Piketon (March 2026): $4.2bn for 10GW; planned customer funding.  
https://www.aep.com/news/stories/view/10823/

[5] JCT JCX-46-21: p.2, item F.1.5; p.8, note 7. Includes direct pay.  
https://www.govinfo.gov/content/pkg/GOVPUB-Y4_T19_4-PURL-gpo172711/pdf/GOVPUB-Y4_T19_4-PURL-gpo172711.pdf

[6] EIA AEO2026 Table5: cb2026.d021826b, years C10:AB10; server energy C33:AB33.  
https://www.eia.gov/outlooks/aeo/excel/aeotab5.xlsx

[7] PJM August2026 NITS: column E; exact zonal cells in [3].  
https://www.pjm.com/-/media/DotCom/markets-ops/settlements/network-integration-trans-service-august-2026-xls.xlsx

[8] PJM 2026 network service peak loads: p.1, Zonal Peak (MW).  
https://www.pjm.com/-/media/DotCom/markets-ops/settlements/network-service-peak-loads-2026.pdf

[9] PJM 2026 forecast: Table B9b, years B7:V7; zone rows8-31.  
https://www.pjm.com/-/media/DotCom/planning/res-adeq/load-forecast/2026-load-report-tables.xlsx

[10] EIA AEO2026 Table54: C81, C136, D136, D140 (national expenditure proxy).  
https://www.eia.gov/outlooks/aeo/supplement/excel/suptab_54.xlsx

[11] Grid Strategies 2025 load-growth report: p.33, 829GW planning-peak proxy.  
https://gridstrategiesllc.com/wp-content/uploads/Grid-Strategies-National-Load-Growth-Report-2025.pdf

[12] Dominion October2024 local plan: selected needs/project pages indexed in [3].  
https://www.pjm.com/-/media/DotCom/committees-groups/committees/teac/2024/20241008/20241008-informational-only---dom-local-plan-submission-of-supplemental-projects-2024.pdf

[13] MISO MTEP25: Appendix A New Local Reliability Projects, IDs50208 and50628.  
https://cdn.misoenergy.org/MTEP25731615.zip

[14] MISO MTEP26 draft: upgrade examples; project matches and limitations in [3].  
https://cdn.misoenergy.org/MTEP26%20-%20Draft784746.zip

[15] Entergy Kline testimony: printed pp.33-34 (PDF pp.35-36), customer funding and term.  
https://lpscpubvalence.lpsc.louisiana.gov/portal/PSC/ViewFile?fileId=AUl4qI5mSHA%3D

